# online-voting-system-using-PHP
SAMPLE IMAGES ARE GIVEN IN LINK
[IMAGES FILE]





[ADMIN IMAGES](https://docs.google.com/document/d/12ZJhS-xcs2cW5QB-VQUUJYhVluY4Pdy2KysCQ6w25fk/edit?usp=sharing)
