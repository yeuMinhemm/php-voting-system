<footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>All rights reserved</b>
      </div>
      <strong>Designed By <a href="https://github.com/harikutty5896/online-voting-system-using-PHP" target="_blank">Hari</a></strong>
    </div>
    <!-- /.container -->
</footer>